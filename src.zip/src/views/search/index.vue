<template>
  <div class="app-container">
    <div class="tree_style">
      <div class="panel-heading">Search Parameters</div>
      <div class="panel-body" style="width: 98%;">
        <el-form
          ref="dataForm"
          :model="listQuery"
          label-position="top"
          label-width="130px"
          style="padding-top:10px;padding-left:10px;"
        >
          <el-form-item label="Search for" prop="type" class="form-item form-bottom">
            <template>
              <el-select
                v-model="subtype"
                placeholder=""
                filterable
              >
                <el-option
                  v-for="item in sublist"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </template>
          </el-form-item>
          <el-form-item v-if="subtype===1" label="Vehicle" prop="icon" class="form-item form-bottom" style="margin-left:10px">
            <template>
              <el-select
                v-model="vehicle_mark"
                placeholder="Any Make"
                filterable
                value-key="value"
                style="margin-bottom:5px"
              >
                <el-option
                  v-for="item in car_marks"
                  :key="item.value"
                  :label="item.key"
                  :value="item.value"
                >
                  <span style="float: left">{{ item.key }}</span>
                  <!--<span style="float: right; color: #8492a6; font-size: 13px">{{ item.value }}</span>-->
                </el-option>
              </el-select>
            </template>
            <template>
              <el-select
                v-model="vehicle_body"
                placeholder="Any Body Type"
                filterable
                value-key="value"
                style="margin-bottom:5px"
              >
                <el-option
                  v-for="item in car_bodys"
                  :key="item.value"
                  :label="item.key"
                  :value="item.value"
                >
                  <span style="float: left">{{ item.key }}</span>
                  <!--<span style="float: right; color: #8492a6; font-size: 13px">{{ item.value }}</span>-->
                </el-option>
              </el-select>
            </template>
            <template>
              <el-select
                v-model="vehicle_color"
                placeholder="Any Color"
                filterable
                value-key="value"
              >
                <el-option
                  v-for="item in car_colors"
                  :key="item.value"
                  :label="item.key"
                  :value="item.value"
                >
                  <span style="float: left">{{ item.key }}</span>
                  <!--<span style="float: right; color: #8492a6; font-size: 13px">{{ item.value }}</span>-->
                </el-option>
              </el-select>
            </template>
          </el-form-item>
          <el-form-item v-if="subtype===1" label="State/Province" class="form-item form-bottom" style="margin-left:10px">
            <template>
              <el-select
                v-model="state"
                placeholder="Any Color"
                filterable
                value-key="value"
              >
                <el-option
                  v-for="item in car_bodys"
                  :key="item.value"
                  :label="item.lebel"
                  :value="item.value"
                >
                  <span style="float: left; color: #8492a6; font-size: 13px">{{ item.label }}</span>
                </el-option>
              </el-select>
            </template>
          </el-form-item>

          <el-form-item v-if="subtype===1" label="Direction" class="form-item form-bottom" style="margin-left:10px">
            <template>
              <el-select
                v-model="direction"
                placeholder="Any Color"
                filterable
                value-key="value"
              >
                <el-option
                  v-for="item in car_colors"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                >
                  <span style="float: left">{{ item.label }}</span>
                  <span style="float: right; color: #8492a6; font-size: 13px">{{ item.value }}</span>
                </el-option>
              </el-select>
            </template>
          </el-form-item>
          <el-form-item v-if="subtype===3" label="Alert List" class="form-item form-bottom" style="margin-left:10px">
            <template>
              <el-select
                v-model="alertlist"
                placeholder="Any List"
                filterable
                value-key="value"
              >
                <el-option
                  v-for="item in alert_list"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                >
                  <span style="float: left">{{ item.label }}</span>
                  <span style="float: right; color: #8492a6; font-size: 13px">{{ item.value }}</span>
                </el-option>
              </el-select>
            </template>
          </el-form-item>

          <el-form-item label="Time Period" class="form-item form-bottom">
            <template>
              <el-date-picker
                v-model="value2"
                :type="dateType"
                :range-separator="$t('time.to')"
                :start-placeholder="$t('time.startTime')"
                :end-placeholder="$t('time.endTime')"
                :default-time="['00:00:00', '23:59:59']"
                align="left"
                style="width:100%"
              />
            </template>
          </el-form-item>
          <el-form-item label="Site" class="form-item form-bottom">
            <template>
              <el-select
                v-model="listQuery.control"
                placeholder="All Sites"
                filterable
                value-key="value"
              >
                <el-option
                  v-for="item in controls"
                  :key="item.value"
                  :label="item.name"
                  :value="item.value"
                >
                  <span style="float: left">{{ item.name }}</span>
                  <span style="float: right; color: #8492a6; font-size: 13px">{{ item.value }}</span>
                </el-option>
              </el-select>
            </template>
          </el-form-item>
          <el-form-item label="Plate Number" class="form-item form-bottom">
            <template>
              <el-input v-model="plateNumber" />
            </template>
          </el-form-item>
        </el-form>
        <el-button v-waves class="filter-item" style="float:right;margin-bottom: 10px;margin-top: 10px;" type="primary" icon="el-icon-search" @click="handleFilter">
          {{ $t(&#x27;table.search&#x27;) }}
        </el-button>
      </div>
    </div>
    <div class="table_60">
      <el-table
        :key="tableKey"
        v-loading="listLoading"
        :data="list"
        border
        fit
        highlight-current-row
        style="width: 100%;"
        @sort-change="sortChange"
        @selection-change="handleSelectionChange"
      >
        <el-table-column label="Site" min-width="100" max-width="150" align="center">
          <template slot-scope="{row}">
            {{ row.control.name }}
          </template>
        </el-table-column>
        <el-table-column label="Camera" min-width="100" align="center">
          <template slot-scope="{row}">
            {{ row.httpdirve.name }}
          </template>
        </el-table-column>
        <el-table-column label="Country" min-width="100" align="center">
          <template slot-scope="{row}">
            {{ row.country }}
          </template>
        </el-table-column>
        <el-table-column label="Plate Number" min-width="120" align="center">
          <template slot-scope="{row}">
            {{ row.licensePlate }}
          </template>
        </el-table-column>
        <el-table-column label="Vehicle" min-width="100" align="center">
          <template slot-scope="{row}">
            {{ row.plateType }}
          </template>
        </el-table-column>
        <el-table-column label="Direction" min-width="100" align="center">
          <template slot-scope="{row}">
            {{ row.direction }}
          </template>
        </el-table-column>
        <el-table-column label="Confidence" min-width="100" align="center">
          <template slot-scope="{row}">
            {{ row.confidenceLevel }}
          </template>
        </el-table-column>
        <el-table-column label="Time" min-width="80" align="center">
          <template slot-scope="{row}">
            {{ row.dateTime | parseTime('{h}:{i}') }}
          </template>
        </el-table-column>
      </el-table>
      <pagination
        :page.sync="listQuery.page"
        :limit.sync="listQuery.limit"
        @pagination="getList"
      />
    </div>
  </div>
</template>

<script>
import Pagination from '@/components/Pagination' // 分页组件Secondary package based on el-pagination
import waves from '@/directive/waves' // Waves directive
import { cutStr } from '@/utils/index'
import { list as checkRecordsList } from '@/api/checkRecords'
import { list as checkList } from '@/api/checks'
import { list as controlList } from '@/api/controls'
import { list as hardwareWordList } from '@/api/hardwareword'
import { list as httpdrivesList } from '@/api/httpDrives'
import { list as wordList } from '@/api/words'
import { list as wordTypeList } from '@/api/wordTypes'
export default {
  name: 'CheckRecordList',
  components: { Pagination },
  directives: { waves }, // 一个按钮的动画效果
  data() {
    return {
      tableKey: 0,
      list: [],
      total: 0,
      listLoading: true,
      fieldOptions: [
        { key: 'name', label: this.$t('checks.checkTitle') }
      ],
      dateType: 'datetimerange',
      listQuery: {
        page: 1,
        limit: 10,
        sort: '-_id',
        time: 'recordTime'
      },
      iconList: [],
      hardMap: {},
      slaveMap: {},
      multipleSelection: [],
      slaveData: [],
      hardData: [],
      car_marks: [],
      car_colors: [],
      car_bodys: [],
      ishard: false,
      cutStr: cutStr,
      checksCascaderData: [],
      checksArr: [],
      tempLastDate: '',
      subtype: 1,
      httpdriveMap: {},
      controlMap: {},
      checks: [],
      controls: [],
      value2: '',
      vehicle_color: '',
      vehicle_mark: '',
      vehicle_body: '',
      state: '',
      direction: '',
      plateNumber: '',
      sublist: [{ label: 'Plates', value: 1 }, { label: 'Plate Candidates', value: 2 }, { label: 'Alerts', value: 3 }]
    }
  },
  async created() {
    await this.getOtherList()
    await this.getList()
  },
  methods: {
    async getOtherList() {
      const word_car = (await wordTypeList({ name: 'car_mark' })).data.rows
      this.car_marks = (await wordList({ wordType: word_car[0]._id })).data.rows
      const word_body = (await wordTypeList({ name: 'car_body' })).data.rows
      this.car_bodys = (await wordList({ wordType: word_body[0]._id })).data.rows
      const word_color = (await wordTypeList({ name: 'car_color' })).data.rows
      this.car_colors = (await wordList({ wordType: word_color[0]._id })).data.rows
      const hardwarewords = (await hardwareWordList({ 'code': 'HIK_TRAFFIC_CA', 'type': 2 })).data.rows
      const hardwareword = hardwarewords[0]
      // 查询设备
      const httpdrives = (await httpdrivesList({ hardwareWord: hardwareword._id })).data.rows
      httpdrives.map((item, index, arr) => {
        this.httpdriveMap[item._id] = item
        arr[index] = item._id
      })
      this.controls = (await controlList({})).data.rows
      for await (const control of this.controls) {
        this.controlMap[control._id] = control
      }
      this.checks = (await checkList({ parentName: 'HttpDrive', 'parents': httpdrives, parentKey: 'parent', shortAddress: '0', autopopulate: false })).data.rows
      await this.checks.map((item, index, arr) => {
        arr[index] = item._id
      })
      this.value2 = []
      const now = new Date()
      const date = now.getDate()
      now.setDate(date - 7)
      now.setSeconds(0)
      now.setMinutes(0)
      now.setHours(0)
      now.setMilliseconds(0)
      const bdate = new Date(now)
      this.value2.push(bdate)
      now.setDate(date)
      now.setSeconds(59)
      now.setMinutes(59)
      now.setHours(23)
      now.setMilliseconds(0)
      const edate = new Date(now)
      this.value2.push(edate)
      this.listQuery.range = this.value2
      this.listQuery.checks = this.checks
    },
    async getList() {
      const _this = this
      checkRecordsList(this.listQuery).then(response => {
        if (response.data.rows.length > 0) {
          response.data.rows.map((item, index, arr) => {
            try {
              if (item.valueStr !== null) {
                arr[index] = JSON.parse(item.valueStr)
                if (_this.httpdriveMap[item.check.parent] !== undefined) {
                  arr[index].httpdirve = _this.httpdriveMap[item.check.parent]
                }
                if (arr[index].httpdirve !== undefined && _this.controlMap[arr[index].httpdirve.control] !== undefined) {
                  arr[index].control = _this.controlMap[arr[index].httpdirve.control]
                }
              }
            } catch (e) {
              console.log(e)
            }
          })
        }
        this.list = response.data.rows
        this.listLoading = false
      })
    },
    async changeChecksCascader(option) {
      if (option) {
        // 单选
        this.listQuery.check = option[option.length - 1]
        // 多选
        // this.listQuery.check = []
        // for (const item of option) {
        //   this.listQuery.check.push(item[item.length - 1])
        // }
      }
    },
    recurTree(data, modelType) { // 重新解析树,把空结尾的树枝去掉
      if (data.model !== modelType && data.children.length === 0) {
        return null
      } else if (data.model !== modelType && data.children.length > 0) {
        const t = []
        data.value = data._id
        data.children.forEach(item => {
          const v = this.recurTree(item, modelType)
          if (v)t.push(v)
        })
        if (t.length > 0) {
          data.children = t
        } else {
          data = null
        }
        return data
      } else {
        return { label: data.label, value: data._id }
      }
    },
    handleFilter() {
      this.listQuery.page = 1
      if (this.value2 === '' || this.value2 === null) {
        return this.$message({
          message: this.$t('messages.del_message'),
          type: 'warning'
        })
      }
      this.listQuery.range = this.value2
      const query = {}
      query['$and'] = []
      if (this.subtype === 1) {
        if (this.vehicle_color) {
          query['$and'].push({ 'valueJSON.vehicle_color': this.vehicle_color })
        }
        if (this.vehicle_mark) {
          query['$and'].push({ 'valueJSON.vehicle_mark': this.vehicle_mark })
        }
        if (this.vehicle_body) {
          query['$and'].push({ 'valueJSON.vehicle_body': this.vehicle_body })
        }
        if (this.direction) {
          query['$and'].push({ 'valueJSON.direction': this.direction })
        }
        if (this.state) {
          query['$and'].push({ 'valueJSON.country': this.state })
        }
      }
      if (this.plateNumber) {
        query['$and'].push({ 'valueJSON.licensePlate': this.plateNumber })
      }
      if (query['$and'].length > 0) {
        this.listQuery.query = JSON.stringify(query)
      }
      console.log(this.listQuery.query)
      this.getList()
    },
    sortChange(data) { // 排序
      const { prop, order } = data
      if (order === 'ascending') {
        this.listQuery.sort = prop
      } else {
        this.listQuery.sort = '-' + prop
      }
      this.handleFilter()
    },
    handleSelectionChange(val) {
      this.multipleSelection = val.map(v => v._id)
    }
    // handleDelete(_id) { // 删除
    //   this.$confirm(this.$t('messages.delete'), this.$t('messages.title'), {
    //     confirmButtonText: this.$t('messages.confirm'),
    //     cancelButtonText: this.$t('messages.cancel'),
    //     type: 'warning'
    //   }).then(() => {
    //     deleteOne(_id).then(() => {
    //       this.getList()
    //       this.$notify({
    //         title: this.$t('messages.success_title'),
    //         message: this.$t('messages.del_success'),
    //         type: 'success',
    //         duration: 2000
    //       })
    //     })
    //   })
    // },
    // handleDeleteQuery(row) {
    //   this.$refs.EditForm.handleDeleteQuery(row, this.hardMap, this.slaveMap, this.checkData)
    // },
    // handleExportQuery(row) {
    //   this.$refs.EditForm.handleExportQuery(row, this.hardMap, this.slaveMap, this.checkData)
    // },
    // handleDeleteCheck() {
    //   if (this.multipleSelection.length <= 0) {
    //     this.$message({
    //       message: this.$t('messages.del_message'),
    //       type: 'warning'
    //     })
    //   } else {
    //     this.$confirm(this.$t('messages.delete'), this.$t('messages.title'), {
    //       confirmButtonText: this.$t('messages.confirm'),
    //       cancelButtonText: this.$t('messages.cancel'),
    //       type: 'warning'
    //     }).then(() => {
    //       deleteMany(this.multipleSelection).then(() => {
    //         this.getList()
    //         this.$notify({
    //           title: this.$t('messages.success_title'),
    //           message: this.$t('messages.del_check_success'),
    //           type: 'success',
    //           duration: 2000
    //         })
    //       })
    //     })
    //   }
    // },
    // handleUpdate(row) {
    //   this.$refs.EditForm.handleUpdate(row)
    // },
    // handleCreate() {
    //   this.$refs.EditForm.handleCreate()
    // },
    // open(valueStr) {
    //   this.$alert('<p style="word-break:break-all;height: 600px;overflow: scroll">' + valueStr + '</p>', '提示', {
    //     dangerouslyUseHTMLString: true
    //   })
    // }
  }
}
</script>
