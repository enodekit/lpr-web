<template xmlns:v-slot="http://www.w3.org/1999/XSL/Transform">
  <el-dialog :title="textMap[dialogStatus]" :visible.sync="dialogFormVisible" @open="dialogOpen">
    <fieldset class="fieldset-dialog">
      <el-form
        ref="dataForm"
        :rules="rules"
        :model="temp"
        label-position="left"
        label-width="100px"
        style="padding-top:10px"
      >
        <el-row>
          <el-col :span="12">
            <el-form-item label="名称" prop="name" class="form-item">
              <el-input v-model="temp.name" placeholder="输入名称" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="短地址" prop="shortAddress" class="form-item">
              <el-input v-model="temp.shortAddress" :disabled="true" placeholder="输入设备唯一地址码" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="设备url" prop="url" class="form-item">
              <el-input v-model="temp.url" :disabled="true" placeholder="http://** or https://**" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item :label="$t('hardware.hardwareWord')" prop="hardwareWord" class="form-item">
              <el-select
                v-model="temp.hardwareWord"
                :placeholder="$t('rules.select')"
                filterable
                :disabled="true"
                @change="loadOpAndCk"
              >
                <el-option
                  v-for="item in hardwareWordList"
                  :key="item._id"
                  :label="item.name"
                  :value="item._id"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item :label="$t('hardware.control')" prop="control" class="form-item">
              <el-select
                v-model="temp.control"
                :placeholder="$t('rules.label')"
                filterable
                :disabled="true"
              >
                <el-option
                  v-for="control in controls"
                  :key="control._id"
                  :label="control.name"
                  :value="control._id"
                />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </fieldset>
    <div slot="footer" class="dialog-footer">
      <el-button @click="dialogFormVisible = false">
        {{ $t(&#x27;table.cancel&#x27;) }}
      </el-button>
      <el-button type="primary" @click="dialogStatus==='create'?createData():updateData()">
        {{ $t(&#x27;table.confirm&#x27;) }}
      </el-button>
    </div>
  </el-dialog>
</template>

<script>
import { updateOne } from '@/api/httpDrives'
import { list as selectHardWareWordList } from '@/api/hardwareword'
import { list as controlList } from '@/api/controls'
import { list as wordList } from '@/api/words'
import { list as wordTypeList } from '@/api/wordTypes'
import { parseInterval } from '@/utils'

export default {
  name: 'HttpDriveForm',
  data() {
    return {
      textMap: {
        update: '修改',
        create: '新增'
      },
      controls: [],
      temp: {},
      createTemp: {},
      dialogFormVisible: false,
      dialogStatus: undefined,
      hardwareWordList: [],
      checks: [],
      operates: [],
      iconCheckList: [],
      iconOperateList: [],
      rules: {
        name: [{ required: true, message: '请输入名称', trigger: 'blur' }]
      }
    }
  },
  computed: {
    plateButtonShow() {
      const result = this.hardwareWordList.filter(item => item._id === this.temp.hardwareWord)[0]
      return result && result.rosterModel && result.rosterModel.length > 0
    }
  },
  methods: {
    parseInterval: parseInterval,
    async dialogOpen() {
      let wordType = (await wordTypeList({ name: '显示图标' })).data.rows
      this.iconCheckList = (await wordList({ wordType: wordType[0]._id })).data.rows
      this.iconCheckList.forEach((item) => {
        item.label = item.name
      })
      wordType = (await wordTypeList({ name: '按钮图标' })).data.rows
      this.iconOperateList = (await wordList({ wordType: wordType[0]._id })).data.rows
      this.iconOperateList.forEach((item) => {
        item.label = item.name
      })
      this.loadSelectData()
    },
    fkBeId(row) { // 外键统一转_id
      if (row.hardwareWord && row.hardwareWord._id) row.hardwareWord = row.hardwareWord._id
      if (row.control && row.control._id) row.control = row.control._id
    },
    async loadSelectData() {
      this.hardwareWordList = (await selectHardWareWordList({ type: 2, autopopulate: false })).data.rows
      this.controls = (await controlList({ autopopulate: false })).data.rows
    },
    handleCreate() { // 新建
      this.dialogStatus = 'create'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.temp = { ...this.createTemp }
        this.$refs['dataForm'].clearValidate()
      })
    },
    handleUpdate(row) {
      this.temp = { ...row } // 复制一个
      this.dialogStatus = 'update'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].clearValidate()
        this.fkBeId(this.temp)
      })
    },
    updateData() { // 更新
      this.$refs['dataForm'].validate(async(valid) => {
        if (valid) {
          const tempData = Object.assign({}, this.temp)
          await updateOne(tempData)
          this.$emit('reload') // 组件触发绑定的reload方法
          this.dialogFormVisible = false
          this.$notify({
            title: '成功',
            message: '更新成功',
            type: 'success',
            duration: 2000
          })
        }
      })
    }
  }
}
</script>
