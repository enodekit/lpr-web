<template>
  <div class="app-container">
    <div class="filter-container">
      <!--      <el-select v-model="listQuery.check" filterable :placeholder="$t('checks.checkTitle')" style="width: 200px;" class="filter-item" clearable>-->
      <!--        <el-option-->
      <!--          v-for="type in checkData"-->
      <!--          :key="type._id"-->
      <!--          :label="type.name"-->
      <!--          :value="type._id"-->
      <!--        >-->
      <!--          <span style="float: left">{{ type.name }}</span>-->
      <!--          <span style="float: right; color: #8492a6; font-size: 13px">{{ type.parent?type.parent.name:'' }}</span>-->
      <!--        </el-option>-->
      <!--      </el-select>-->
      <el-cascader
        v-model="checksArr"
        style="width:300px;margin-bottom:10px"
        :show-all-levels="false"
        collapse-tags
        placeholder=""
        :options="checksCascaderData"
        :props="{ multiple: false, expandTrigger: 'hover' }"
        filterable
        @change="changeChecksCascader"
      />
      <el-button v-waves class="filter-item" type="primary" icon="el-icon-search" @click="handleFilter">
        {{ $t(&#x27;table.search&#x27;) }}
      </el-button>
      <el-button class="filter-item" style="margin-left: 10px;" type="primary" icon="el-icon-delete" @click="handleDeleteQuery">
        {{ $t(&#x27;table.query_delete&#x27;) }}
      </el-button>
      <el-button class="filter-item" style="margin-left: 10px;" type="primary" icon="el-icon-download" @click="handleExportQuery">
        {{ $t(&#x27;route.exportExcel&#x27;) }}
      </el-button>

      <el-button v-waves class="filter-item" type="primary" icon="el-icon-delete" @click="handleDeleteCheck">
        {{ $t(&#x27;table.delete&#x27;) }}
      </el-button>
    </div>

    <el-table
      :key="tableKey"
      v-loading="listLoading"
      :data="list"
      border
      fit
      highlight-current-row
      style="width: 100%;"
      @sort-change="sortChange"
      @selection-change="handleSelectionChange"
    >
      <el-table-column prop="_id" type="selection" align="center" width="50px" fixed />
      <el-table-column :label="$t('checks.hardTitle')" align="center" min-width="220">
        <template slot-scope="{row}">
          <span>{{ row.check.parent?row.check.parent.name:'' }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="check" :label="$t('checks.checkTitle')" sortable="custom" align="center" min-width="120">
        <template slot-scope="scope">
          <span>{{ scope.row.check?scope.row.check.name:scope.row.check }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="value" :label="$t('checks.valueTitle')" align="center" width="120">
        <template slot-scope="scope">
          <span>{{ scope.row.value }}{{ scope.row.check.company!=undefined?scope.row.check.company:'' }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="valueStr" label="字符值" align="center" width="120">
        <template slot-scope="scope">
          <el-button type="text" @click="open(scope.row.valueStr)">
            <span>{{ cutStr(6,scope.row.valueStr,'...') }}</span>
          </el-button>
        </template>
      </el-table-column>
      <el-table-column prop="recordTime" :label="$t('checks.recordTime')" sortable="custom" align="center" min-width="120">
        <template slot-scope="scope">
          <span>{{ scope.row.recordTime| parseTime(&#x27;{y}-{m}-{d} {h}:{i}:{s}&#x27;) }}</span>
        </template>
      </el-table-column>
      <el-table-column :label="$t('table.actions')" fixed="right" align="center" width="140" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button size="mini" type="danger" @click="handleDelete(scope.row._id)">
            {{ $t(&#x27;table.delete&#x27;) }}
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <pagination
      :total="total"
      :page.sync="listQuery.page"
      :limit.sync="listQuery.limit"
      @pagination="getList"
    />
    <edit-form ref="EditForm" @reload="getList" />
  </div>
</template>

<script>
import { list, deleteOne, deleteMany } from '@/api/checkRecords'
// import { list as hardList } from '@/api/hardwares'
// import { list as slaveList } from '@/api/loraSlaves'
// import { valueList as checkReduceRecordValueList } from '@/api/checkReduceRecords'
import { list as checkList, tree as treeChecks } from '@/api/checks'
import Pagination from '@/components/Pagination' // 分页组件Secondary package based on el-pagination
import waves from '@/directive/waves' // Waves directive
import editForm from './edit'
import { cutStr } from '@/utils/index'
export default {
  name: 'CheckRecordList',
  components: { Pagination, editForm },
  directives: { waves }, // 一个按钮的动画效果
  data() {
    return {
      tableKey: 0,
      list: [],
      total: 0,
      listLoading: true,
      fieldOptions: [
        { key: 'name', label: this.$t('checks.checkTitle') }
      ],
      listQuery: {
        page: 1,
        limit: 10,
        sort: '-_id'
      },
      hardMap: {},
      slaveMap: {},
      multipleSelection: [],
      slaveData: [],
      hardData: [],
      checkData: [],
      ishard: false,
      cutStr: cutStr,
      checksCascaderData: [],
      checksArr: []
    }
  },
  async created() {
    await this.getOtherList()
    await this.getList()
  },
  methods: {
    async getOtherList() {
      // await hardList({ autopopulate: false }).then(response => {
      //   this.hardData = response.data.rows
      //   const hardMap = {}
      //   response.data.rows.forEach(function(item) {
      //     hardMap[item._id] = item
      //   })
      //   this.hardMap = hardMap
      // })
      // await slaveList({ autopopulate: false }).then(response => {
      //   this.slaveData = response.data.rows
      //   const slaveMap = {}
      //   response.data.rows.forEach(function(item) {
      //     slaveMap[item._id] = item
      //   })
      //   this.slaveMap = slaveMap
      // })
      this.slaveMap = {}
      await checkList({ autopopulate: true }).then(response => {
        this.checkData = response.data.rows
        this.checkData.forEach((item) => {
          if (item.loraSlave) {
            item.parentName = 'LoraSlave'
            item.parent = item.loraSlave
          }
          if (item.hardware) {
            item.parentName = 'Hardware'
            item.parent = item.hardware
          }
          if (item.parent !== null && item.parent !== undefined) {
            this.slaveMap[item.parent._id] = item.parent
          }
        })
      })
      const checksTree = (await treeChecks()).data
      const checksTreeArr = []
      checksTree.forEach(item => {
        const v = this.recurTree(item, 'Check')
        if (v)checksTreeArr.push(v)
      })
      this.checksCascaderData = checksTreeArr
    },
    async getList() {
      // const abc = {
      //   time: 'recordTime',
      //   range: [1577260000021, 1577262700021],
      //   // 'value.reduce': '5e00582ab6840822a1a3c986',
      //   'value.check': '5dca4427aff828001c1e00e3'
      // }
      // abc['value.reduce'] = '5e00582ab6840822a1a3c986'
      // const checkReduceRecords = await checkReduceRecordValueList(abc)
      // console.log(checkReduceRecords, 'checkReduceRecords', abc)
      this.listLoading = true
      list(this.listQuery).then(response => {
        response.data.rows.forEach((item) => {
          if (item.check && this.slaveMap[item.check.loraSlave ? item.check.loraSlave : item.check.hardware ? item.check.hardware : item.check.parent]) {
            item.check.parent = this.slaveMap[item.check.loraSlave ? item.check.loraSlave : item.check.hardware ? item.check.hardware : item.check.parent]
            // if (item.check.loraSlave) {
            //
            // }
            // if (item.check.loraSlave && this.slaveMap[item.check.loraSlave] !== undefined) {
            //   item.check.loraSlave = this.slaveMap[item.check.loraSlave].name
            //   item.check.hardware = ''
            // } else {
            //   if (item.check.hardware && this.hardMap[item.check.hardware]) {
            //     if (this.slaveMap[this.hardMap[item.check.hardware].loraSlave]) {
            //       item.check.loraSlave = this.slaveMap[this.hardMap[item.check.hardware].loraSlave].name
            //     } else {
            //       item.check.loraSlave = ''
            //     }
            //     item.check.hardware = this.hardMap[item.check.hardware].name
            //   } else {
            //     item.check.hardware = ''
            //   }
            // }
          } else {
            item.check = {}
            item.check.parent = undefined
          }
        })
        this.total = response.data.total
        this.list = response.data.rows
        this.listLoading = false
      })
    },
    async changeChecksCascader(option) {
      if (option) {
        // 单选
        this.listQuery.check = option[option.length - 1]
        // 多选
        // this.listQuery.check = []
        // for (const item of option) {
        //   this.listQuery.check.push(item[item.length - 1])
        // }
      }
    },
    recurTree(data, modelType) { // 重新解析树,把空结尾的树枝去掉
      if (data.model !== modelType && data.children.length === 0) {
        return null
      } else if (data.model !== modelType && data.children.length > 0) {
        const t = []
        data.value = data._id
        data.children.forEach(item => {
          const v = this.recurTree(item, modelType)
          if (v)t.push(v)
        })
        if (t.length > 0) {
          data.children = t
        } else {
          data = null
        }
        return data
      } else {
        return { label: data.label, value: data._id }
      }
    },
    handleFilter() {
      this.listQuery.page = 1
      this.getList()
    },
    sortChange(data) { // 排序
      const { prop, order } = data
      if (order === 'ascending') {
        this.listQuery.sort = prop
      } else {
        this.listQuery.sort = '-' + prop
      }
      this.handleFilter()
    },
    handleSelectionChange(val) {
      this.multipleSelection = val.map(v => v._id)
    },
    handleDelete(_id) { // 删除
      this.$confirm(this.$t('messages.delete'), this.$t('messages.title'), {
        confirmButtonText: this.$t('messages.confirm'),
        cancelButtonText: this.$t('messages.cancel'),
        type: 'warning'
      }).then(() => {
        deleteOne(_id).then(() => {
          this.getList()
          this.$notify({
            title: this.$t('messages.success_title'),
            message: this.$t('messages.del_success'),
            type: 'success',
            duration: 2000
          })
        })
      })
    },
    handleDeleteQuery(row) {
      this.$refs.EditForm.handleDeleteQuery(row, this.hardMap, this.slaveMap, this.checkData)
    },
    handleExportQuery(row) {
      this.$refs.EditForm.handleExportQuery(row, this.hardMap, this.slaveMap, this.checkData)
    },
    handleDeleteCheck() {
      if (this.multipleSelection.length <= 0) {
        this.$message({
          message: this.$t('messages.del_message'),
          type: 'warning'
        })
      } else {
        this.$confirm(this.$t('messages.delete'), this.$t('messages.title'), {
          confirmButtonText: this.$t('messages.confirm'),
          cancelButtonText: this.$t('messages.cancel'),
          type: 'warning'
        }).then(() => {
          deleteMany(this.multipleSelection).then(() => {
            this.getList()
            this.$notify({
              title: this.$t('messages.success_title'),
              message: this.$t('messages.del_check_success'),
              type: 'success',
              duration: 2000
            })
          })
        })
      }
    },
    handleUpdate(row) {
      this.$refs.EditForm.handleUpdate(row)
    },
    handleCreate() {
      this.$refs.EditForm.handleCreate()
    },
    open(valueStr) {
      this.$alert('<p style="word-break:break-all;height: 600px;overflow: scroll">' + valueStr + '</p>', '提示', {
        dangerouslyUseHTMLString: true
      })
    }
  }
}
</script>
