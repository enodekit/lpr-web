<template>
  <el-dialog :title="textMap[dialogStatus]" :visible.sync="dialogFormVisible" @open="dialogOpen" @close="dialogClose">
    <div
      v-loading="loading"
      class="fieldset-dialog"
    >
      <el-form :inline="true" :model="listQuery" label-position="left" label-width="100px" style=" margin-left:50px;margin-right:50px;padding-top:10px">
        <el-form-item v-show="dialogStatus==='export'" :label="$t('checks.export_title')" class="form-item">
          <el-select v-model="export_T" filterable value-key="_id" style="width: 400px;" class="filter-item" @change="changeDateType()">
            <el-option
              v-for="type in exportTypes"
              :key="type.label"
              :label="type.label"
              :value="type.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item :label="$t('checks.recordTime')" class="form-item">
          <el-date-picker
            v-model="value2"
            :type="dateType"
            :range-separator="$t('checks.to')"
            :start-placeholder="$t('checks.startTime')"
            :end-placeholder="$t('checks.endTime')"
            :default-time="['00:00:00', '23:59:59']"
            align="left"
            style="width:100%"
          />
        </el-form-item>
        <el-form-item v-show="dialogStatus==='export'&&export_T===1" :label="$t('checks.time')" class="form-item">
          <el-input v-model="dtime" type="number" :placeholder="$t('table.time_title')" />
        </el-form-item>
        <el-form-item v-show="dialogStatus==='export'" :label="$t('checks.checkTitle')" class="form-item">
          <el-select v-model="listQuery.checks" multiple :placeholder="$t('checks.checkTitle')" filterable value-key="_id" style="width: 400px;" class="filter-item" clearable>
            <el-option
              v-for="type in checkData"
              :key="type._id"
              :label="type.name"
              :value="type._id"
            >
              <span style="float: left">{{ type.name }}</span>
              <span style="float: right; color: #8492a6; font-size: 13px">{{ type.parent?type.parent.name:'' }}</span>
            </el-option>
          </el-select>
        </el-form-item>
      </el-form>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button @click="dialogFormVisible = false">
        {{ $t(&#x27;table.cancel&#x27;) }}
      </el-button>
      <el-button type="primary" :loading="downloadLoading" @click="dialogStatus==='delete'?deleteData():exportExecl()">
        {{ $t(&#x27;table.confirm&#x27;) }}
      </el-button>
    </div>
  </el-dialog>
</template>

<script>
import { list, execlist, deleteMany, sequential } from '@/api/checkRecords'
import { parseInterval, parseTime } from '@/utils'

export default {
  name: 'CheckRecordForm',
  components: { },
  data() {
    return {
      connected: false,
      loading: false,
      textMap: {
        update: this.$t('dialog.update'),
        create: this.$t('dialog.create'),
        delete: this.$t('dialog.delete'),
        export: this.$t('route.exportExcel')
      },
      listQuery: {
        sort: { recordTime: 1 },
        time: 'recordTime',
        range: []
      },
      group: { _id: '$check', tvs: { $push: { _id: '$_id', value: '$value', recordTime: '$recordTime' }}},
      value2: '',
      dtime: 10,
      dateType: 'datetimerange',
      export_T: 0,
      list: [],
      dialogFormVisible: false,
      dialogStatus: undefined,
      downloadLoading: false,
      filename: '',
      autoWidth: true,
      bookType: 'xlsx',
      hardMap: {},
      slaveMap: {},
      checkMap: {},
      checkData: [],
      exportTypes: [{ value: 0, label: this.$t('checks.export_normal') }, { value: 1, label: this.$t('checks.export_sequential') }]
    }
  },
  watch: {
    'temp.hardwareWord': function(val, oldVal) {
      const word = this.hardwareWordList.filter(item => item._id === val)[0]
      if (word) {
        this.temp.serialData = word.serialData
        this.temp.attribute = word.attribute
        this.serialList = [this.temp.serialData]
      }
    }
  },
  methods: {
    parseInterval: parseInterval,
    dialogOpen() {

    },
    changeDateType() {
      if (this.export_T === '0') {
        this.dateType = 'datetimerange'
      } else {
        this.dateType = 'daterange'
      }
    },
    dialogClose() { // 关闭后关闭串口接管

    },
    handleDeleteQuery(row, hardMap, slaveMap, checkData) { // 新建
      this.hardMap = hardMap
      this.slaveMap = slaveMap
      this.checkData = checkData
      this.dialogStatus = 'delete'
      this.dialogFormVisible = true
    },
    handleExportQuery(row, hardMap, slaveMap, checkData) { // 新建
      this.hardMap = hardMap
      this.slaveMap = slaveMap
      this.checkData = checkData
      this.checkData.forEach((item) => {
        this.checkMap[item._id] = item
      })
      this.dialogStatus = 'export'
      this.dialogFormVisible = true
    },
    async deleteData() {
      this.downloadLoading = true
      let ids = []
      if (this.value2 === '') {
        return this.$message({
          message: this.$t('messages.del_message'),
          type: 'warning'
        })
      }
      this.listQuery.range = this.value2
      if (this.listQuery.group !== undefined) {
        delete this.listQuery.group
      }
      await list(this.listQuery).then(response => {
        ids = response.data.rows.map(v => v._id)
      })
      if (ids.length <= 0) {
        this.downloadLoading = false
        this.$message({
          message: this.$t('messages.del_none_message'),
          type: 'warning'
        })
      } else {
        deleteMany(ids).then(() => {
          this.$emit('reload') // 组件触发绑定的reload方法
          this.dialogFormVisible = false
          this.downloadLoading = false
          this.$notify({
            title: this.$t('messages.success_title'),
            message: this.$t('messages.del_check_success'),
            type: 'success',
            duration: 2000
          })
        })
      }
    },
    async exportExecl() {
      this.downloadLoading = true
      this.listQuery.range = this.value2
      if (this.export_T === 0) {
        this.listQuery.autopopulate = false
        if (this.listQuery.group !== undefined) {
          delete this.listQuery.group
        }
        await execlist(this.listQuery).then(response => {
          response.data.forEach((item) => {
            const list = item
            if (item.check !== null && this.checkMap[item.check] !== undefined) {
              list.loraSlave = this.checkMap[item.check].loraSlave
              list.hardware = this.checkMap[item.check].hardware
              list.checkName = this.checkMap[item.check].name
              list.value = item.value + '' + (item.check.company !== undefined ? item.check.company : '')
              this.list.push(list)
            }
          })
        })
      } else {
        const bt = this.value2[0]
        this.listQuery.group = this.group
        await sequential(this.listQuery).then(response => {
          let last = {}
          response.data.rows.forEach((item) => {
            if (this.checkMap[item._id] !== undefined) {
              const list = {}
              list.checkName = this.checkMap[item._id].name
              const company = this.checkMap[item._id].company !== undefined ? this.checkMap[item._id].company : ''
              list.loraSlave = this.checkMap[item._id].loraSlave
              list.hardware = this.checkMap[item._id].hardware
              list.recordTime = new Date(bt).getTime()
              item.tvs.forEach((tv) => {
                if (list.value === undefined) {
                  list.value = tv.value + '' + company
                  last = tv
                  const n = Object.assign({}, list)
                  n.recordTime = new Date(n.recordTime)
                  this.list.push(n)
                  list.recordTime = list.recordTime + this.dtime * 60 * 1000
                } else {
                  if (new Date(tv.recordTime).getTime() < list.recordTime) {
                    last = tv
                  } else {
                    const ft = Math.abs(new Date(last.recordTime).getTime() - list.recordTime)
                    const et = Math.abs(new Date(tv.recordTime).getTime() - list.recordTime)
                    if (ft >= et) {
                      list.value = tv.value + '' + company
                    } else {
                      list.value = last.value + '' + company
                    }
                    const n = Object.assign({}, list)
                    n.recordTime = new Date(n.recordTime)
                    this.list.push(n)
                    list.recordTime = list.recordTime + this.dtime * 60 * 1000
                  }
                }
              })
            }
          })
        })
      }
      // console.log(JSON.stringify(this.list))
      import('@/vendor/Export2Excel').then(async excel => {
        const tHeader = ['Lora', 'HardWare', 'Check', 'Value', 'RecordTime']
        const filterVal = ['loraSlave', 'hardware', 'checkName', 'value', 'recordTime']
        const data = this.formatJson(filterVal, this.list)
        await excel.export_json_to_excel({
          header: tHeader,
          data,
          filename: this.$t('checks.export_name'),
          autoWidth: this.autoWidth,
          bookType: this.bookType
        })
        this.downloadLoading = false
        this.dialogFormVisible = false
      })
    },
    formatJson(filterVal, jsonData) {
      return jsonData.map(v => filterVal.map(j => {
        if (j === 'timestamp') {
          return parseTime(v[j])
        } else {
          return v[j]
        }
      }))
    }
  }
}
</script>
