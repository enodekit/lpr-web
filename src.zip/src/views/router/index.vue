<template>
  <div class="app-container">
    <div class="filter-container">
      <el-button class="filter-item" style="margin-left: 10px;" type="primary" icon="el-icon-edit" @click="addMenuItem(undefined,'brother')">
        添加顶级路由
      </el-button>
      <el-button class="filter-item" style="margin-left: 10px;" type="primary" icon="el-icon-edit" @click="$refs.Gen.formVisible=true">
        后端路由生成
      </el-button>
      <div class="filter-item" style="margin-left: 10px;">
        <el-tag>展开</el-tag>
        <el-switch
          v-model="defaultExpandAll"
          active-color="#13ce66"
          inactive-color="#ff4949"
          @change="reset"
        />
      </div>
    </div>

    <tree-table
      ref="TreeTable"
      :key="key"
      v-loading="listLoading"
      :default-expand-all="defaultExpandAll"
      :data="data"
      :columns="columns"
      border
    >
      <template slot="type" slot-scope="{scope}">
        <span>{{ scope.row.type==='menu'?'前端路由':'后端路由' }}</span>
      </template>
      <template slot="roles" slot-scope="{scope}">
        <el-tag v-for="role in scope.row.roles " :key="role._id">{{ role.name }}</el-tag>
      </template>
      <template slot="operation" slot-scope="{scope}">
        <el-button
          size="small"
          type="text"
          @click="addMenuItem(scope.row,'brother')"
        >
          添加同级
        </el-button>
        <el-button
          size="small"
          type="text"
          @click="addMenuItem(scope.row,'children')"
        >
          添加子级
        </el-button>
        <el-button
          size="small"
          type="text"
          @click="handleUpdate(scope.row)"
        >
          修改
        </el-button>
        <el-button
          size="small"
          type="text"
          @click="handleDelete(scope.row._id)"
        >
          删除
        </el-button>
      </template>
    </tree-table>
    <edit-router ref="EditFrom" @reload="getList" />
    <generato-router ref="Gen" />
  </div>
</template>

<script>
import { list, create, deleteOne, updateOne } from '@/api/router'
import treeTable from '@/components/TreeTable'
import generatoRouter from './generator'
import editRouter from './edit'
import waves from '@/directive/waves' // Waves directive

export default {
  name: 'RouterList',
  components: { treeTable, generatoRouter, editRouter },
  directives: { waves }, // 一个按钮的动画效果
  data() {
    return {
      listLoading: true,
      defaultExpandAll: false,
      key: 1,
      columns: [
        {
          label: '多选',
          checkbox: true
        },
        {
          label: '名称',
          key: 'name',
          expand: true
        },
        {
          label: '类型',
          key: 'type'
        },
        {
          label: '路径',
          key: 'path',
          width: 200,
          align: 'left'
        },
        {
          label: 'method',
          key: 'method',
          width: 80,
          align: 'left'
        },
        {
          label: '拥有权限的角色',
          key: 'roles'
        },
        {
          label: '操作',
          key: 'operation'
        }
      ],
      data: [],
      createTemp: { // 临时表单
        _id: undefined,
        name: '新路由',
        type: 'menu',
        children: [],
        roles: []
      }
    }
  },
  created() {
    this.getList()
  },
  methods: {
    reset() {
      ++this.key
    },
    getList() {
      this.listLoading = true
      list({ level: 0 }).then(response => {
        this.data = response.data
        this.listLoading = false
      })
    },
    addMenuItem(row, type) {
      const data = { ...this.createTemp }
      if (type === 'children') {
        this.$refs.TreeTable.addChild(row, data)
        create({ ...data }).then((res) => {
          data._id = res.data._id
          const children = new Set(row.children.map(child => child._id))
          children.add(res.data._id)
          updateOne({ _id: row._id, children })
        })
      }
      if (type === 'brother') {
        this.$refs.TreeTable.addBrother(row, data)
        if (row === undefined || row._parent === null) {
          data.level = 0
        }
        create(data).then((res) => {
          data._id = res.data._id
          if (row === undefined || row._parent === null) return
          const children = new Set(row._parent.children.map(child => child._id))
          children.push(res.data._id)
          updateOne({ _id: row._parent._id, children })
        })
      }
    },
    handleDelete(_id) { // 删除
      deleteOne(_id).then(() => {
        this.getList()
        this.$notify({
          title: '成功',
          message: '删除成功',
          type: 'success',
          duration: 2000
        })
      })
    },
    handleUpdate(row) {
      this.$refs.EditFrom.handleUpdate(row)
    }
  }
}
</script>
