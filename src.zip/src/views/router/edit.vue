<template>
  <el-dialog :title="textMap[dialogStatus]" :visible.sync="dialogFormVisible" @open="dialogOpen">
    <el-form ref="dataForm" :rules="rules" :model="temp" label-position="left" label-width="70px" style="width: 400px; margin-left:50px;">
      <el-form-item label="类型" prop="type">
        <el-select v-model="temp.type" placeholder="请选择类型">
          <el-option
            v-for="item in option1"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="名称" prop="name">
        <el-input v-model="temp.name" placeholder="输入名称" />
      </el-form-item>
      <el-form-item label="路径" prop="path">
        <el-input v-model="temp.path" />
      </el-form-item>
      <el-form-item label="method" prop="method">
        <el-select v-model="temp.method" clearable placeholder="请选择">
          <el-option
            v-for="item in option2"
            :key="item"
            :label="item"
            :value="item"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="子级" prop="children">
        <el-select v-model="temp.children" multiple clearable filterable remote reserve-keyword placeholder="请选择">
          <el-option
            v-for="item in option3"
            :key="item._id"
            :label="(item.name||item.path)+' '+(item.method?item.method:'')"
            :value="item._id"
          />
        </el-select>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="dialogFormVisible = false">
        {{ $t('table.cancel') }}
      </el-button>
      <el-button type="primary" @click="updateData()">
        {{ $t('table.confirm') }}
      </el-button>
    </div>
  </el-dialog>
</template>

<script>
import { updateOne, list } from '@/api/router'
export default {
  name: 'Edit',
  data() {
    return {
      textMap: {
        update: '修改',
        create: 'Create'
      },
      temp: {},
      dialogFormVisible: false,
      dialogStatus: undefined,
      rules: {
        name: [{ required: true, message: '请输入名称', trigger: 'blur' }]
      }, // 表单验证
      option1: [{ value: 'menu', label: '前端路由' }, { value: 'api', label: '后端路由' }],
      option2: ['get', 'post', 'put', 'delete'],
      option3: undefined
    }
  },
  methods: {
    dialogOpen() {
      list().then(response => {
        this.option3 = response.data.rows
      })
    },
    handleUpdate(row) {
      this.temp = { ...row } // 复制一个
      if (this.temp.children) this.temp.children = this.temp.children.map(child => child._id)
      delete this.temp._parent
      this.dialogStatus = 'update'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].clearValidate()
      })
    },
    updateData() { // 更新
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          const tempData = Object.assign({}, this.temp)
          updateOne(tempData).then(() => {
            this.$emit('reload')
            this.dialogFormVisible = false
            this.$notify({
              title: '成功',
              message: '更新成功',
              type: 'success',
              duration: 2000
            })
          })
        }
      })
    }
  }
}
</script>
