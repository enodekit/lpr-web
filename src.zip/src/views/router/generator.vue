<template>
  <el-dialog title="路由生成" :visible.sync="formVisible">
    <el-form ref="dataForm" :model="temp" label-position="left" :rules="rules" label-width="90px" style="width: 400px; margin-left:50px;">
      <el-form-item label="名称" prop="name">
        <el-input v-model="temp.name" />
      </el-form-item>
      <el-form-item label="后端路由" prop="filepath">
        <el-input v-model="temp.filepath" />
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="formVisible = false">
        {{ $t('table.cancel') }}
      </el-button>
      <el-button type="primary" @click="createData()">
        {{ $t('table.confirm') }}
      </el-button>
    </div>
  </el-dialog>
</template>

<script>
import { generator } from '@/api/router'
export default {
  name: 'Generator',
  data() {
    return {
      formVisible: false,
      temp: {
        filepath: ''
      },
      rules: {
        name: [{ required: true, message: '请输入名称', trigger: 'blur' }],
        filepath: [{ required: true, message: '请输入文件名', trigger: 'blur' }]
      } // 表单验证
    }
  },
  methods: {
    createData() {
      generator(this.temp).then(res => {
        this.formVisible = false
        this.$notify({
          title: '成功',
          message: '生成成功',
          type: 'success',
          duration: 2000
        })
      }).catch(err => {
        this.$notify({
          title: '失败',
          message: err.response.data.message,
          type: 'error',
          duration: 2000
        })
      })
    }
  }
}
</script>

<style scoped>

</style>
