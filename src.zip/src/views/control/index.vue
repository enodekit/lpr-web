<template>
  <div class="app-container">
    <div class="filter-container">
      <el-select
        v-model="listQuery.label"
        :placeholder="$t('table.search_label')"
        clearable
        class="filter-item"
        style="width: 130px"
        @change="textclean"
      >
        <el-option v-for="item in fieldOptions" :key="item.key" :label="item.label" :value="item.key" />
      </el-select>
      <el-input
        v-model="listQuery.search"
        :placeholder="$t('table.search_message')"
        style="width: 200px;"
        class="filter-item"
        @keyup.enter.native="handleFilter"
      />

      <el-button v-waves class="filter-item" type="primary" icon="el-icon-search" @click="handleFilter">
        {{ $t(&#x27;table.search&#x27;) }}
      </el-button>
      <el-button
        class="filter-item"
        style="margin-left: 10px;"
        type="primary"
        icon="el-icon-edit"
        @click="handleCreate"
      >
        {{ $t(&#x27;table.add&#x27;) }}
      </el-button>
      <el-button
        v-if="$store.getters.roles.includes('admin')&&newPiList.total>0"
        v-waves
        class="filter-item"
        type="primary"
        icon="el-icon-search"
        @click="handleNewPi"
      >
        {{ $t('control.new_Pi_List') }}({{ newPiList.total }})
      </el-button>
    </div>
    <!--<div class="tree_style">-->

    <!--<el-input-->
    <!--v-model="filterText"-->
    <!--placeholder="输入关键字进行过滤"-->
    <!--/>-->
    <!--<el-tree-->
    <!--ref="tree2"-->
    <!--:data="treeData"-->
    <!--:props="defaultProps"-->
    <!--:filter-node-method="filterNode"-->
    <!--style="width: 95%;"-->
    <!--default-expand-all-->
    <!--accordion-->
    <!--@node-click="handleNodeClick"-->
    <!--/>-->
    <!--</div>-->

    <!--<div style="width:84%;float: right;">-->
    <div>
      <el-table
        :key="tableKey"
        v-loading="fullscreenLoading"
        :element-loading-text="$t('table.loading_text')"
        element-loading-spinner="el-icon-loading"
        element-loading-background="rgba(255, 255, 255, 0.8)"
        :data="list"
        border
        fit
        highlight-current-row
        style="width: 100%;"
        @sort-change="sortChange"
        @selection-change="handleSelectionChange"
      >
        <el-table-column prop="_id" type="selection" align="center" width="50px" fixed />
        <el-table-column prop="name" :label="$t('control.name')" sortable="custom" align="center" min-width="150" />
        <el-table-column prop="number" :label="$t('control.number')" sortable="custom" align="center" min-width="120" />
        <el-table-column prop="line" :label="$t('control.line_type')" sortable="custom" align="center" min-width="100">
          <template slot-scope="{row}">
            <span>{{ row.line===true?$t('messages.onLine'):$t('messages.offLine') }}</span>
          </template>
        </el-table-column>
        <el-table-column
          prop="onlineTime"
          :label="$t('control.line_time')"
          sortable="custom"
          align="center"
          min-width="150"
        >
          <template slot-scope="{row}">
            <span>{{ new Date(row.onlineTime)|parseTime('{y}-{m}-{d} {h}:{i}') }}</span>
          </template>
        </el-table-column>
        <el-table-column
          prop="ip_address"
          :label="$t('control.ip_address')"
          sortable="custom"
          align="center"
          width="130"
        />
        <el-table-column
          prop="clientId"
          :label="$t('control.mqtt_clientId')"
          sortable="custom"
          align="center"
          min-width="120"
        />
        <el-table-column
          :label="$t('table.actions')"
          fixed="right"
          align="center"
          min-width="100"
          class-name="small-padding fixed-width"
        >
          <template slot-scope="{row}">
            <el-button type="primary" size="mini" class="m_b_5" @click="handleUpdate(row)">
              {{ $t(&#x27;table.edit&#x27;) }}
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <pagination
        v-show="total>0"
        :total="total"
        :page.sync="listQuery.page"
        :limit.sync="listQuery.limit"
        @pagination="getList"
      />
      <edit-form ref="EditForm" @reload="getList" />
    </div>
  </div>
</template>

<script>
import { list, deleteOne, getNewPi } from '@/api/controls'
// import { tree as getTreeData } from '@/api/user'

import Pagination from '@/components/Pagination' // 分页组件Secondary package based on el-pagination
import editForm from './edit'
import waves from '@/directive/waves' // Waves directive

export default {
  name: 'ControlList',
  components: { Pagination, editForm },
  directives: { waves }, // 一个按钮的动画效果
  data() {
    return {
      tableKey: 0,
      list: null,
      total: 0,
      filterText: '',
      treeData: [],
      defaultProps: {
        children: 'children',
        label: 'label'
      },
      role: process.env.VUE_APP_ROLE,
      // treeQuery: {
      //   fieldName: 'trueName',
      //   allName: '用户列表' // 用于显示全部
      // },
      fieldOptions: [
        { key: 'name', label: this.$t('control.name') },
        { key: 'number', label: this.$t('control.number') }
      ], lineOptions: [{
        value: 'all',
        label: this.$t('route.all')
      }, {
        value: 'true',
        label: this.$t('messages.onLine')
      }, {
        value: 'false',
        label: this.$t('messages.offLine')
      }],
      listQuery: {
        page: 1,
        limit: 10,
        sort: '-createdAt'

      },
      multipleSelection: [],
      newPiList: {},
      fullscreenLoading: false,
      configControlLoad: false,
      configLoraLoad: false
    }
  },
  watch: {
    filterText(val) {
      this.$refs.tree2.filter(val)
    }
  },
  created() {
    this.getList()
    // this.getTreeData()
    if (process.env.VUE_APP_ROLE === 'serve') { // 服务端才能获取新设备信息
      getNewPi().then(res => {
        this.newPiList = res.data
      })
    }
  },
  methods: {
    getList() {
      this.fullscreenLoading = true
      list(this.listQuery).then(response => {
        this.list = response.data.rows
        this.total = response.data.total
        this.fullscreenLoading = false
      })
    },
    handleFilter() {
      this.listQuery.page = 1
      this.getList()
    },
    sortChange(data) { // 排序
      const { prop, order } = data
      if (order === 'ascending') {
        this.listQuery.sort = prop
      } else {
        this.listQuery.sort = '-' + prop
      }
      this.handleFilter()
    },
    handleSelectionChange(val) {
      this.multipleSelection = val.map(v => v._id)
    },
    handleDelete(_id) { // 删除
      this.$confirm(this.$t('messages.delete'), this.$t('messages.title'), {
        confirmButtonText: this.$t('messages.confirm'),
        cancelButtonText: this.$t('messages.cancel'),
        type: 'warning'
      }).then(() => {
        deleteOne(_id).then(() => {
          this.getList()
          this.$notify({
            title: this.$t('messages.success_title'),
            message: this.$t('messages.del_success'),
            type: 'success',
            duration: 2000
          })
        })
      })
    },
    handleUpdate(row) {
      this.$refs.EditForm.handleloading = true
      this.$refs.EditForm.handleUpdate(row)
    },
    handleCreate() {
      this.$refs.EditForm.handleloading = true
      this.$refs.EditForm.handleCreate()
    },
    handleNodeClick(data) {
      if (data.level === -1) {
        delete this.listQuery._id
        delete this.listQuery.creator
      } else if (data.level === 0) {
        this.listQuery.creator = data._id
        delete this.listQuery._id
      } else if (data.level === 1) {
        this.listQuery._id = data._id
        delete this.listQuery.creator
      }
      this.getList()
    },
    filterNode(value, data) {
      if (!value) return true
      return data.label.indexOf(value) !== -1
    },
    operation: function(row) {
      this.operationLoad = true
      this.$router.push({
        name: 'operation',
        query: { id: row._id }
      })
    },
    configControl: function(row) {
      this.configControlLoad = true
      this.$router.push({
        name: 'configControl',
        query: { id: row._id },
        params: { username: row.creator.mqttUsername, clientId: row.clientId }
      })
    },
    configLora: function(row) {
      this.configLoraLoad = true
      this.$router.push({
        name: 'configLora',
        params: { clientId: row.clientId }
      })
    },
    simpleConfig: function(row) {
      this.configLoraLoad = true
      this.$router.push({
        name: 'simpleConfigIndex',
        params: { clientId: row.clientId }
      })
    },
    textclean: function() {
      this.listQuery.search = ''
    }
  }
}
</script>
<style scoped>
  .m_b_5 {
    margin-bottom: 5px;
  }
</style>
