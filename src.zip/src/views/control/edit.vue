<template xmlns:v-slot="http://www.w3.org/1999/XSL/Transform">
  <el-dialog :title="textMap[dialogStatus]" :visible.sync="dialogFormVisible" width="65%" @open="dialogOpen">
    <fieldset class="fieldset-dialog">
      <el-form
        ref="dataForm"
        :rules="rules"
        :model="temp"
        label-position="left"
        label-width="150px"
        style="padding-top:10px"
      >
        <el-row>
          <el-col :span="12">
            <el-form-item :label="$t('control.name')" prop="name" class="form-item">
              <el-input v-model="temp.name" :placeholder="$t('control.ph_name')" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item :label="$t('control.number')" prop="number" class="form-item">
              <el-input v-model="temp.number" type="" :placeholder="$t('control.ph_number')" :disabled="true" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="位置" prop="address" class="form-item">
              <el-input v-model="temp.address" type="" :placeholder="$t('control.ph_number')" />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </fieldset>
    <fieldset class="fieldset-dialog" style="margin-top:10px">
      <template>
        <map
          :center="center"
          :zoom="7"
        >
          <marker
            v-for="m in markers"
            :position.sync="m.position"
            :clickable="true"
            :draggable="true"
            @g-click="center=m.position"
          />
        </map>
      </template>
    </fieldset>
    <div slot="footer" class="dialog-footer">
      <el-button @click="dialogFormVisible = false">
        {{ $t(&#x27;table.cancel&#x27;) }}
      </el-button>
      <el-button type="primary" :loading="dialogLoading" @click="dialogStatus==='create'?createData():updateData()">
        {{ $t(&#x27;table.confirm&#x27;) }}
      </el-button>
    </div>
  </el-dialog>
</template>

<script>
import { updateOne } from '@/api/controls'
import { list as wordList } from '@/api/controlword'
import { list as userList } from '@/api/user'
import { BAUD_RATES, CHECKS, STOP_BITS, DATA_BITS } from '@/utils/constant'
import { list as hardwareWordList } from '@/api/hardwareword'
// import { list as packageList } from '@/api/packages'
import { parseTime } from '@/utils/index'
import { load, Map, Marker } from 'vue-google-maps'
load('YOUR_API_TOKEN', 'OPTIONAL VERSION NUMBER')

export default {
  name: 'ControlForm',
  components: [Map, Marker],
  data() {
    return {
      users: [],
      simTypelist: [{ label: '移动-46002', value: 0 }, { label: '联通46001', value: 1 }],
      baudList: BAUD_RATES, // 波特率列表
      verificaList: CHECKS, // 校验列表
      stopBitList: STOP_BITS, // 停止位列表
      dataBitList: DATA_BITS, // 数据位列表
      textMap: {
        update: this.$t('dialog.update'),
        create: this.$t('dialog.create')
      },
      temp: {
      },
      createTemp: {
        name: '',
        number: '',
        phone: '',
        icCid: '',
        simType: '',
        line: false,
        // onlineTime: '',
        // ip_address: '',
        // login_time: '',
        // lastsend: '',
        // env: '',
        clientId: '',
        version: '',
        driveDownAt: '',
        packageData: {}
      },
      dialogFormVisible: false,
      dialogStatus: undefined,
      controlSelectList: [],
      mqttClients: [],
      packageList: [],
      rules: {
        name: [{ required: true, message: this.$t('rules.name'), trigger: 'blur' }]
      },
      serialRule: {
        comName: [{ required: true, message: this.$t('rules.name') }],
        baud: [{ required: true, message: this.$t('rules.baud') }],
        verification: [{ required: true, message: this.$t('rules.verification') }],
        stopBit: [{ required: true, message: this.$t('rules.stopBit') }],
        dataBit: [{ required: true, message: this.$t('rules.dataBit') }]
      },
      packageRule: {
        name: [{ required: true, message: this.$t('rules.name') }]
      },
      clientId: undefined,
      mqttUser: undefined,
      handleloading: false,
      dialogLoading: false,
      hardwareWords: [],
      packageDatas: [],
      center: { lat: 10.0, lng: 10.0 },
      markers: [{
        position: { lat: 10.0, lng: 10.0 }
      }, {
        position: { lat: 11.0, lng: 11.0 }
      }]
    }
  },
  computed: {
    isAdmin() {
      return this.$store.getters.roles.includes('admin')
    }
  },
  methods: {
    formatter(row, column) {
      return parseTime(row[column], '{y}-{m}-{d}')
    },
    async dialogOpen() {
      this.packageDatas = []
      const result = await userList({ limit: 100 })
      this.users = result.data.rows
      this.handleloading = false
    },
    // // 选择中控字典后将对应的串口信息带过来
    // importPort(_id) {
    //   this.temp.serialData = this.controlSelectList.filter(item => item._id === _id)[0].serialData
    // },
    // importPackage(data) {
    //   this.temp.packageData = this.packageList.filter(item => item._id === data.row.name)[0]
    //   if (this.temp.packageData !== null) {
    //     const year = this.temp.packageData.year
    //     data.row.year = year
    //     data.row.number = this.temp.packageData.number
    //     const date = new Date()
    //     data.row.activeTime = parseTime(date, '{y}-{m}-{d}')
    //     let month = year * 12
    //     month = month + date.getMonth()
    //     data.row.exceedTime = parseTime(date.setMonth(month), '{y}-{m}-{d}')
    //     data.row.hardwareWord = this.temp.packageData.hardwareWord
    //   }
    // },
    // async handleCreate(opts) { // 新建
    //   if (opts) {
    //     this.clientId = opts.clientId
    //     this.mqttUser = opts.mqttUser
    //   }
    //   this.dialogStatus = 'create'
    //   this.dialogFormVisible = true
    //   this.hardwareWords = (await hardwareWordList({ autopopulate: false })).data.rows
    //   this.controlSelectList = (await wordList()).data.rows // 中控字典表\
    //   // this.packageList = (await packageList()).data.rows
    //   this.$nextTick(() => {
    //     this.temp = { ...this.createTemp }
    //     this.$refs['dataForm'].clearValidate()
    //     this.handleloading = false
    //   })
    // },
    // async validate() {
    //   try {
    //     await this.$refs['dataForm'].validate()
    //     await this.$refs.serialTable.fullValidate()
    //     this.temp.serialData = this.$refs.serialTable.getTableData().fullData
    //     return true
    //   } catch (e) {
    //     return false
    //   }
    // },
    // async createData() {
    //   this.dialogLoading = true
    //   if (!await this.validate()) {
    //     this.dialogLoading = false
    //     return this.$message.error(this.$t('messages.validate_error'))
    //   }
    //   try {
    //     await create(this.temp)
    //   } catch (err) {
    //     this.dialogLoading = false
    //     return this.$notify({
    //       title: this.$t('messages.error'),
    //       message: err.response.data.message,
    //       type: 'error',
    //       duration: 2000
    //     })
    //   }
    //   this.$emit('reload') // 组件触发绑定的reload方法
    //   this.dialogFormVisible = false
    //   this.dialogLoading = false
    //   this.$notify({
    //     title: this.$t('messages.success_title'),
    //     message: this.$t('messages.create_success'),
    //     type: 'success',
    //     duration: 2000
    //   })
    // },
    async handleUpdate(row) {
      this.handleloading = true
      this.temp = { ...row } // 复制一个
      if (this.temp.children) this.temp.children = this.temp.children.map(child => child._id)
      delete this.temp._parent
      this.dialogStatus = 'update'
      this.dialogFormVisible = true
      this.hardwareWords = (await hardwareWordList({ autopopulate: false })).data.rows
      this.controlSelectList = (await wordList()).data.rows // 中控字典表
      // this.packageList = (await packageList()).data.rows
      this.packageDatas.push(this.temp.packageData)
      this.$nextTick(() => {
        this.$refs['dataForm'].clearValidate()
        this.handleloading = false
      })
    },
    async updateData() { // 更新
      this.dialogLoading = true
      if (!await this.validate()) {
        this.dialogLoading = false
        return this.$message.error(this.$t('messages.validate_error'))
      }
      const tempData = Object.assign({}, this.temp)
      await updateOne(tempData)
      this.$emit('reload') // 组件触发绑定的reload方法
      this.dialogFormVisible = false
      this.dialogLoading = false
      this.$notify({
        title: this.$t('messages.success_title'),
        message: this.$t('messages.update_success'),
        type: 'success',
        duration: 2000
      })
    }
    // insertPackage() { // 插入并选中
    //   this.$refs.packageTable.insert({})
    //     .then(({ row }) => {
    //       this.$refs.packageTable.setActiveCell(row, 'name')
    //     })
    // },
    // removePackage(row) {
    //   this.$refs.packageTable.remove(row)
    // },
    // insertSerial() { // 插入并选中
    //   this.$refs.serialTable.insert({ comName: '/dev', state: false })
    //     .then(({ row }) => {
    //       console.log(this.list)
    //       this.$refs.serialTable.setActiveCell(row, 'comName')
    //     })
    // },
    // removeSerial(row) {
    //   this.$refs.serialTable.remove(row)
    // },
    // editMqttClient(clientId) {
    //   this.$router.push({ name: 'configControl', query: { id: this.temp._id }, params: { username: this.temp.creator.mqttUsername, clientId: clientId }})
    // }
  }
}
</script>
