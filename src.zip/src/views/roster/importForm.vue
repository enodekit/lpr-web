<template>
  <el-dialog title="导入" :visible.sync="dialogFormVisible" @open="dialogOpen">
    <el-form ref="dataForm" :rules="rules" :model="temp" label-position="left" label-width="100px" style="width: 85%; margin-left:50px;">
      <el-form-item label="导入方式" prop="path">
        <el-select
          v-model="temp.state"
        >
          <el-option
            v-for="item in [{name:'重写导入',value:0},{name:'添加导入',value:1}]"
            :key="item.value"
            :label="item.name"
            :value="item.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="导入文件" prop="path">
        <single-file v-model="temp.file" type="string" />
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="dialogFormVisible = false">
        导入
      </el-button>
      <el-button type="primary" @click="importData()">
        {{ $t(&#x27;table.confirm&#x27;) }}
      </el-button>
    </div>
  </el-dialog>
</template>

<script>
import { importRosters } from '@/api/rosters'
import SingleFile from '@/components/Upload/SingleFile'

export default {
  name: 'RosterImportForm',
  components: { SingleFile },
  data() {
    return {
      rosterModel: [],
      temp: {},
      createTemp: {
        state: 0
      },
      dialogFormVisible: false,
      dialogStatus: undefined,
      rules: {}
    }
  },
  methods: {
    dialogOpen() {

    },
    handleImport(control, hardwareWord) { // 新建
      this.dialogStatus = 'create'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.temp = { ...this.createTemp }
        this.temp.control = control
        this.temp.hardwareWord = hardwareWord
        this.$refs['dataForm'].clearValidate()
      })
    },
    importData() {
      this.$refs['dataForm'].validate(async(valid) => {
        if (valid) {
          await importRosters(this.temp)
          this.$emit('reload') // 组件触发绑定的reload方法
          this.dialogFormVisible = false
          this.$notify({
            title: '成功',
            message: '导入成功',
            type: 'success',
            duration: 2000
          })
        }
      })
    }
  }
}
</script>
