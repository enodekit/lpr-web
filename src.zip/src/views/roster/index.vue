<template>
  <div class="app-container">
    <div class="filter-container">
      <el-select v-model="listQuery.control" placeholder="网关" class="filter-item" style="width: 130px" @change="getList">
        <el-option v-for="item in controls" :key="item._id" :label="item.name" :value="item._id" />
      </el-select>
      <el-select v-model="listQuery.hardwareWord" placeholder="设备名单" class="filter-item" style="width: 130px" @change="getList">
        <el-option v-for="item in hardwareWords" :key="item._id" :label="item.name" :value="item._id" />
      </el-select>
      <el-button v-waves class="filter-item" type="primary" icon="el-icon-search" @click="handleFilter">
        {{ $t(&#x27;table.search&#x27;) }}
      </el-button>
      <el-button class="filter-item" style="margin-left: 10px;" type="primary" icon="el-icon-edit" @click="handleCreate">
        {{ $t(&#x27;table.add&#x27;) }}
      </el-button>
      <el-button v-waves class="filter-item" type="primary" icon="el-icon-delete" @click="handleDeleteCheck">
        {{ $t(&#x27;table.delete&#x27;) }}
      </el-button>
      <el-button v-waves class="filter-item" type="primary" icon="el-icon-delete" @click="handleImport">
        导入
      </el-button>
      <el-button v-waves class="filter-item" type="primary" icon="el-icon-delete" @click="handleExport">
        导出
      </el-button>
      <el-button v-waves class="filter-item" type="primary" icon="el-icon-delete" @click="handleUpload">
        上传网关名单
      </el-button>
      <el-button v-waves class="filter-item" type="primary" icon="el-icon-delete" @click="handleDownload">
        网关下载名单
      </el-button>
    </div>

    <el-table
      :key="tableKey"
      v-loading="listLoading"
      :data="list"
      border
      fit
      highlight-current-row
      style="width: 100%;"
      @sort-change="sortChange"
      @selection-change="handleSelectionChange"
    >
      <el-table-column prop="_id" type="selection" align="center" width="50" fixed />
      <el-table-column v-for="item in rosterModel" :key="item._id" :label="item.name" align="center">
        <template slot-scope="scope">
          <span>{{ scope.row.value[item.name] }}</span>
        </template>
      </el-table-column>
      <el-table-column :label="$t('table.actions')" fixed="right" align="center" width="200" class-name="small-padding fixed-width">
        <template slot-scope="{row}">
          <el-button type="primary" size="mini" @click="handleUpdate(row)">
            {{ $t(&#x27;table.edit&#x27;) }}
          </el-button>
          <el-button size="mini" type="danger" @click="handleDelete(row._id)">
            {{ $t(&#x27;table.delete&#x27;) }}
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <pagination v-show="total>0" :total="total" :page.sync="listQuery.page" :limit.sync="listQuery.limit" @pagination="getList" />
    <edit-form ref="EditForm" @reload="getList" />
    <import-form ref="ImportForm" @reload="getList" />
  </div>
</template>

<script>
import { list as wordList } from '@/api/hardwareword'
import { list as controlList, downloadRoster, uploadRoster } from '@/api/controls'
import { list, deleteOne, deleteMany, exportRosters } from '@/api/rosters'
import Pagination from '@/components/Pagination' // 分页组件Secondary package based on el-pagination
import editForm from './edit'
import importForm from './importForm'

import waves from '@/directive/waves' // Waves directive

export default {
  name: 'RosterList',
  components: { Pagination, editForm, importForm },
  directives: { waves }, // 一个按钮的动画效果
  data() {
    return {
      tableKey: 0,
      list: null,
      total: 0,
      listLoading: false,
      hardwareWords: [],
      controls: [],
      rosterModel: [],
      filepath: undefined,
      fieldOptions: [],
      listQuery: {
        page: 1,
        limit: 10,
        sort: '-_id'
      },
      multipleSelection: []
    }
  },
  async created() {
    this.hardwareWords = (await wordList({ query: { 'rosterModel.0': { $exists: true }}})).data.rows
    console.log(this.hardwareWords)
    if (this.hardwareWords.length > 0 && this.hardwareWords[0] !== undefined) {
      this.listQuery.hardwareWord = this.hardwareWords[0]._id
    }
    this.controls = (await controlList()).data.rows
    this.getList()
  },
  methods: {
    getList() {
      if (this.listQuery.hardwareWord != null) {
        this.rosterModel = this.hardwareWords.filter(item => item._id === this.listQuery.hardwareWord)[0].rosterModel
        this.listLoading = true
        list(this.listQuery).then(response => {
          this.list = response.data.rows
          this.total = response.data.total
          this.listLoading = false
        })
      }
    },
    handleFilter() {
      this.listQuery.page = 1
      this.getList()
    },
    sortChange(data) { // 排序
      const { prop, order } = data
      if (order === 'ascending') {
        this.listQuery.sort = prop
      } else {
        this.listQuery.sort = '-' + prop
      }
      this.handleFilter()
    },
    handleSelectionChange(val) {
      this.multipleSelection = val.map(v => v._id)
    },
    handleDelete(_id) { // 删除
      this.$confirm(this.$t('messages.delete'), this.$t('messages.title'), {
        confirmButtonText: this.$t('messages.confirm'),
        cancelButtonText: this.$t('messages.cancel'),
        type: 'warning'
      }).then(() => {
        deleteOne(_id).then(() => {
          this.getList()
          this.$notify({
            title: this.$t('messages.success_title'),
            message: this.$t('messages.del_success'),
            type: 'success',
            duration: 2000
          })
        })
      })
    },
    handleDeleteCheck() {
      if (this.multipleSelection.length <= 0) {
        this.$message({
          message: this.$t('messages.del_message'),
          type: 'warning'
        })
      } else {
        this.$confirm(this.$t('messages.delete'), this.$t('messages.title'), {
          confirmButtonText: this.$t('messages.confirm'),
          cancelButtonText: this.$t('messages.cancel'),
          type: 'warning'
        }).then(() => {
          deleteMany(this.multipleSelection).then(() => {
            this.getList()
            this.$notify({
              title: this.$t('messages.success_title'),
              message: this.$t('messages.del_check_success'),
              type: 'success',
              duration: 2000
            })
          })
        })
      }
    },
    handleUpdate(row) {
      this.$refs.EditForm.handleUpdate(row, this.rosterModel)
    },
    handleCreate() {
      this.$refs.EditForm.handleCreate(this.rosterModel, this.listQuery.control, this.listQuery.hardwareWord)
    },
    handleImport() {
      if (!this.listQuery.control || !this.listQuery.hardwareWord) {
        return this.$notify({
          title: '错误',
          message: '请先选择设备字段和网关',
          type: 'error',
          duration: 2000
        })
      }
      this.$refs.ImportForm.handleImport(this.listQuery.control, this.listQuery.hardwareWord)
    },
    async handleExport() {
      if (!this.listQuery.control || !this.listQuery.hardwareWord) {
        return this.$notify({
          title: '错误',
          message: '请先选择设备字段和网关',
          type: 'error',
          duration: 2000
        })
      }
      const response = await exportRosters({ hardwareWord: this.listQuery.hardwareWord, control: this.listQuery.control })
      const url = URL.createObjectURL(new Blob([response.data]))
      const fileName = response.headers['content-disposition']
      // 对于<a>标签，只有 Firefox 和 Chrome（内核） 支持 download 属性
      // IE10以上支持blob但是依然不支持download
      if ('download' in document.createElement('a')) { // 支持a标签download的浏览器
        const link = document.createElement('a')// 创建a标签
        link.download = fileName// a标签添加属性
        link.style.display = 'none'
        link.href = url
        document.body.appendChild(link)
        link.click()// 执行下载
        URL.revokeObjectURL(link.href) // 释放url
        document.body.removeChild(link)// 释放标签
      } else { // 其他浏览器
        navigator.msSaveBlob(response.data, fileName)
      }
    },
    async handleUpload() {
      if (!this.listQuery.control) {
        return this.$notify({
          title: '错误',
          message: '请先选择网关',
          type: 'error',
          duration: 2000
        })
      }
      await uploadRoster(this.listQuery.control)
      this.$notify({
        title: '成功',
        message: '同步完成',
        type: 'success',
        duration: 2000
      })
    },
    async handleDownload() {
      if (!this.listQuery.control) {
        return this.$notify({
          title: '错误',
          message: '请先选择网关',
          type: 'error',
          duration: 2000
        })
      }
      await downloadRoster(this.listQuery.control)
      this.$notify({
        title: '成功',
        message: '同步完成',
        type: 'success',
        duration: 2000
      })
    }
  }
}
</script>
