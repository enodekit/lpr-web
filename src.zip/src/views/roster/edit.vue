<template>
  <el-dialog :title="textMap[dialogStatus]" :visible.sync="dialogFormVisible" @open="dialogOpen">
    <el-form ref="dataForm" :rules="rules" :model="temp" label-position="left" label-width="100px" style="width: 85%; margin-left:50px;">
      <el-form-item v-for="item in rosterModel" :key="item._id" :label="item.name" :prop="item.name">
        <el-input v-model="temp.value[item.name]" />
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="dialogFormVisible = false">
        {{ $t(&#x27;table.cancel&#x27;) }}
      </el-button>
      <el-button type="primary" @click="dialogStatus==='create'?createData():updateData()">
        {{ $t(&#x27;table.confirm&#x27;) }}
      </el-button>
    </div>
  </el-dialog>
</template>

<script>
import { create, updateOne } from '@/api/rosters'
export default {
  name: 'RosterForm',
  data() {
    return {
      textMap: {
        update: '修改',
        create: '新增'
      },
      rosterModel: [],
      temp: {},
      createTemp: {
        value: {}
      },
      dialogFormVisible: false,
      dialogStatus: undefined,
      rules: {}
    }
  },
  methods: {
    dialogOpen() {

    },
    handleCreate(rosterModel, control, hardwareWord) { // 新建
      this.dialogStatus = 'create'
      this.dialogFormVisible = true
      this.rosterModel = rosterModel
      this.$nextTick(() => {
        this.temp = { ...this.createTemp }
        this.temp.control = control
        this.temp.hardwareWord = hardwareWord
        this.rosterModel.forEach(item => {
          if (item.def) this.temp.value[item.name] = item.def
        })
        this.$refs['dataForm'].clearValidate()
      })
    },
    createData() {
      this.$refs['dataForm'].validate(async(valid) => {
        if (valid) {
          await create(this.temp)
          this.$emit('reload') // 组件触发绑定的reload方法
          this.dialogFormVisible = false
          this.$notify({
            title: '成功',
            message: '创建成功',
            type: 'success',
            duration: 2000
          })
        }
      })
    },
    handleUpdate(row, rosterModel) {
      this.rosterModel = rosterModel
      this.temp = { ...row } // 复制一个
      this.dialogStatus = 'update'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].clearValidate()
      })
    },
    updateData() { // 更新
      this.$refs['dataForm'].validate(async(valid) => {
        if (valid) {
          const tempData = Object.assign({}, this.temp)
          await updateOne(tempData)
          this.$emit('reload') // 组件触发绑定的reload方法
          this.dialogFormVisible = false
          this.$notify({
            title: '成功',
            message: '更新成功',
            type: 'success',
            duration: 2000
          })
        }
      })
    }
  }
}
</script>
