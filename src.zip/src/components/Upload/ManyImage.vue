<template>
  <span>待开发</span>
</template>
<script>
export default {
  name: 'ManyImage'
}
</script>

<style scoped>

</style>
