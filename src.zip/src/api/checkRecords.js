import requestData from '@/utils/data-server-request-v1'
export function list(query) {
  return requestData({
    url: '/check-records',
    method: 'get',
    params: query
  })
}

export function create(data) {
  return requestData({
    url: '/check-records',
    method: 'post',
    data
  })
}

export function updateOne(data) {
  return requestData({
    url: `/check-records/${data._id}`,
    method: 'put',
    data
  })
}

export function deleteOne(id) {
  return requestData({
    url: `/check-records/${id}`,
    method: 'delete'
  })
}

export function deleteMany(ids) {
  return requestData({
    url: '/check-records',
    method: 'delete',
    data: ids // delete传递主体要包含在data里
  })
}

export function execlist(query) {
  return requestData({
    url: '/check-records/execl-list',
    method: 'get',
    params: query
  })
}
export function valuelist(query) {
  return requestData({
    url: '/check-records/value-list',
    method: 'get',
    params: query
  })
}

export function sequential(query) {
  return requestData({
    url: '/check-records/sequential',
    method: 'get',
    params: query
  })
}
export function count(query) {
  return requestData({
    url: '/check-records/count',
    method: 'get',
    params: query
  })
}
