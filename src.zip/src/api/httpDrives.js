import request from '@/utils/request'

export function list(query) {
  return request({
    url: '/http-drives',
    method: 'get',
    params: query
  })
}

export function create(data) {
  return request({
    url: '/http-drives',
    method: 'post',
    data
  })
}

export function updateOne(data) {
  return request({
    url: `/http-drives/${data._id}`,
    method: 'put',
    data
  })
}

export function deleteOne(id) {
  return request({
    url: `/http-drives/${id}`,
    method: 'delete'
  })
}

export function deleteMany(ids) {
  return request({
    url: '/http-drives',
    method: 'delete',
    data: ids // delete传递主体要包含在data里
  })
}

export function config(id) {
  return request({
    url: `/http-drives/${id}/config`,
    method: 'get'
  })
}

export function importRoster(id) {
  return request({
    url: `/http-drives/${id}/import-roster`,
    method: 'get'
  })
}

