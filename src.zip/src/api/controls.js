import request from '@/utils/request'

export function list(query) {
  return request({
    url: '/controls',
    method: 'get',
    params: query
  })
}

export function getOne(id) {
  return request({
    url: `/controls/${id}`,
    method: 'get'
  })
}
export function getCount() {
  return request({
    url: `/controls/count`,
    method: 'get'
  })
}
export function updateOne(data) {
  return request({
    url: `/controls/${data._id}`,
    method: 'put',
    data
  })
}

export function tree(query) {
  return request({
    url: '/controls/tree',
    method: 'get',
    params: query
  })
}

